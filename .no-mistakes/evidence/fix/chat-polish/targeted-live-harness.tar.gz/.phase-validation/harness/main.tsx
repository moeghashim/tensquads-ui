import React from 'react';
import { createRoot } from 'react-dom/client';
import { Chat, ChatLog, ChatComposer, ChatWorking, ChatError, ChatAssistantMessage, ChatUserMessage, useChat } from '../../packages/ui/src/react/index.ts';
import '../../packages/ui/src/fonts.css';
import '../../packages/ui/src/tokens/tokens.css';
import '../../packages/ui/src/styles/styles.css';
const locale = new URLSearchParams(location.search).get('locale') === 'ar' ? 'ar' : 'en';
document.documentElement.lang = locale;
document.documentElement.dir = locale === 'ar' ? 'rtl' : 'ltr';
document.documentElement.dataset.theme = locale === 'ar' ? 'dark' : 'light';
function Example() {
 const chat = useChat({ endpoint: '/validation-chat', locale });
 return <main style={{height: '650px', maxWidth: '850px', margin: 'auto'}}><h1>Local chat error integration</h1><Chat><ChatLog>{chat.turns.map((turn, i) => turn.role === 'user' ? <ChatUserMessage key={i}>{turn.content}</ChatUserMessage> : turn.role === 'assistant' ? <ChatAssistantMessage key={i}>{turn.content}</ChatAssistantMessage> : null)}{chat.busy && <ChatWorking locale={locale}/>} {chat.error && <ChatError locale={locale} onRetry={chat.retry}>{chat.error.message}</ChatError>}</ChatLog><ChatComposer locale={locale} busy={chat.busy} onSend={chat.send} onStop={chat.stop}/></Chat></main>;
}
createRoot(document.getElementById('root')!).render(<Example/>);
