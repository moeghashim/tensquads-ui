import { defineConfig } from '@playwright/test';
export default defineConfig({
 testDir: '../e2e', testMatch: ['phase-live.spec.ts', 'chat-arrow.spec.ts', 'chat-composer.spec.ts'], workers: 1,
 timeout: 30000, reporter: [['list'], ['json', { outputFile: '/Users/moeghashim/.no-mistakes/evidence/01M7SDQ2ZG4ZG3DSC0CCR9NX10/browser-results.json' }]],
 outputDir: '/Users/moeghashim/.no-mistakes/evidence/01M7SDQ2ZG4ZG3DSC0CCR9NX10/browser-traces',
 use: {baseURL: 'http://localhost:5173', browserName: 'chromium', viewport: {width: 1440, height: 900}, trace: 'retain-on-failure'},
 webServer: {command: 'npm --prefix apps/preview run preview', cwd: '..', url: 'http://localhost:5173', reuseExistingServer: false, timeout: 60000}
});
