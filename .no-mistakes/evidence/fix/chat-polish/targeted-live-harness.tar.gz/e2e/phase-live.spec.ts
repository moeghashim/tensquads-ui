import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';
import { expect, test } from '@playwright/test';
import { openPreview, expectAccessible, expectNoHorizontalScroll } from './helpers/preview';
const evidence = '/Users/moeghashim/.no-mistakes/evidence/01M7SDQ2ZG4ZG3DSC0CCR9NX10';
const cases = [
 {locale:'en', direction:'ltr', store:'Store name', email:'Email me when done', monthly:'Monthly', approve:'Approve plan', replay:'Replay', message:'Try a message', send:'Send', stop:'Stop', working:'Working', defaultStore:'Bannaa Market', followup:'Plan approved for A **B**. I will send Monthly updates. Email notifications are off.'},
 {locale:'ar', direction:'rtl', store:'اسم المتجر', email:'أرسل إليّ إشعاراً عند الانتهاء', monthly:'شهري', approve:'اعتماد الخطة', replay:'إعادة العرض', message:'جرّب إرسال رسالة', send:'إرسال', stop:'إيقاف', working:'جارٍ العمل', defaultStore:'متجر بنّاء', followup:'تم اعتماد خطة A **B**. سأرسل تحديثات شهري. إشعارات البريد غير مفعّلة.'}
] as const;
for(const state of cases) {
 for(const theme of ['light','dark'] as const) {
  test(`Approve and Replay reset edited chat in ${state.locale}/${theme}`, async ({page}) => {
   await openPreview(page, {...state, theme}, '/chat');
   const field = page.getByRole('textbox', {name:state.store});
   await expect(field).toBeVisible();
   const initialStore = await field.inputValue();
   await field.fill('A **B**');
   await page.getByRole('switch', {name:state.email}).click();
   await page.getByRole('radio', {name:state.monthly, exact:true}).click();
   await page.screenshot({path:`${evidence}/chat-${state.locale}-${theme}-desktop.png`, fullPage:true});
   await page.getByRole('button', {name:state.approve, exact:true}).click();
   await expect(page.locator('.ts-chat-reply__markdown').last()).toHaveText(state.followup);
   await expect(field).toBeDisabled();
   await expect(page.getByRole('switch', {name:state.email})).toBeDisabled();
   await expect(page.getByRole('radio', {name:state.monthly, exact:true})).toBeDisabled();
   await expect(page.locator('.ts-chat__user-message').last()).toHaveText(state.approve);
   await expectAccessible(page);
   await expectNoHorizontalScroll(page);
   await page.screenshot({path:`${evidence}/chat-${state.locale}-${theme}-approved-mobile.png`, fullPage:true});
   // README's Replay contract: changes and locks must be discarded.
   await page.getByRole('button', {name:state.replay, exact:true}).click();
   await expect(page.getByRole('button', {name:state.approve, exact:true})).toBeEnabled();
   await expect(field).toHaveValue(initialStore);
   await expect(page.getByRole('switch', {name:state.email})).toBeChecked();
   await expect(page.locator('.ts-chat__user-message')).toHaveCount(1);
   await expect(page.locator('.chat-demo__steps')).toHaveCount(1);
   await expect(page.locator('.ts-chat__assistant')).toHaveCount(1);
   await page.screenshot({path:`${evidence}/chat-${state.locale}-${theme}-replayed-mobile.png`, fullPage:true});
  });
 }
 test(`Working, Stop, rapid Replay and reduced motion in ${state.locale}`, async ({page}) => {
  await openPreview(page, {...state, theme:'light'}, '/chat');
  await expect(page.getByRole('button', {name:state.approve,exact:true})).toBeVisible();
  const replay = page.getByRole('button', {name:state.replay,exact:true});
  await replay.click();
  await expect(page.locator('.ts-chat__working')).toHaveText(state.working);
  await page.screenshot({path:`${evidence}/chat-${state.locale}-working.png`,fullPage:true});
  const composer = page.getByRole('textbox', {name:state.message});
  await composer.fill('Pending draft');
  await page.getByRole('button', {name:state.stop,exact:true}).click();
  await expect(composer).toHaveValue('Pending draft');
  await expect(page.locator('.ts-chat__working')).toHaveCount(0);
  await page.waitForTimeout(1150);
  await expect(page.locator('.ts-chat__assistant')).toHaveCount(0);
  await expect(page.getByRole('button', {name:state.send,exact:true})).toBeEnabled();
  await replay.click(); await replay.click(); await replay.click();
  await expect(page.getByRole('button', {name:state.approve,exact:true})).toBeEnabled();
  await expect(page.locator('.ts-chat__user-message')).toHaveCount(1);
  await expect(page.locator('.ts-chat__assistant')).toHaveCount(1);
  await expect(page.locator('.chat-demo__steps')).toHaveCount(1);
  await page.emulateMedia({reducedMotion:'reduce'});
  await replay.click();
  await expect(page.getByRole('button', {name:state.approve,exact:true})).toBeEnabled();
  await expect(page.locator('.ts-chat__working')).toHaveCount(0);
 });
}
const previewRequire = createRequire(new URL('../apps/preview/package.json', import.meta.url));
const {createServer} = await import(pathToFileURL(previewRequire.resolve('vite')).href);
let server: any; let url: string;
test.beforeAll(async () => {
 const attempts = new Map<string, number>();
 server = await createServer({configFile:false, root: `${process.cwd()}/.phase-validation/harness`, server:{host:'127.0.0.1',port:0,fs:{allow:[process.cwd()]}}, plugins:[{name:'disposable-chat-endpoint', configureServer(vite:any){vite.middlewares.use('/validation-chat', (req:any,res:any) => {let body=''; req.on('data',(chunk:any)=>body+=chunk); req.on('end',()=> {const {locale}=JSON.parse(body); const n=(attempts.get(locale)||0)+1; attempts.set(locale,n); res.setHeader('content-type', n===1?'application/json':'text/plain'); res.statusCode=n===1?503:200; res.end(n===1?JSON.stringify({error:'Local service temporarily unavailable'}):'Recovered local reply'); });});}}]});
 await server.listen(); url=server.resolvedUrls.local[0];
});
test.afterAll(async()=> {await server?.close();});
for(const state of cases) {
 test(`Local HTTP failure renders ChatError and Retry recovers in ${state.locale}`, async({page})=> {
  await page.goto(`${url}?locale=${state.locale}`);
  const message=page.getByRole('textbox', {name:state.locale==='en'?'Message':'رسالة'});
  await message.fill('Local service request');
  await page.getByRole('button',{name:state.send,exact:true}).click();
  const alert=page.getByRole('alert');
  await expect(alert).toContainText(state.locale==='en'?'Something went wrong':'حدث خطأ');
  await expect(alert).toContainText('Local service temporarily unavailable');
  await page.screenshot({path:`${evidence}/chat-error-${state.locale}.png`,fullPage:true});
  await page.getByRole('button',{name:state.locale==='en'?'Retry':'إعادة المحاولة',exact:true}).click();
  await expect(page.locator('.ts-chat__assistant')).toHaveText('Recovered local reply');
  await expect(alert).toHaveCount(0);
  await expect(page.locator('.ts-chat__user-message')).toHaveCount(1);
  await page.screenshot({path:`${evidence}/chat-error-${state.locale}-recovered.png`,fullPage:true});
 });
}
