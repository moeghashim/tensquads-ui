import React, {useState} from 'react';
import {ThemeToggle, themePreference, themeInitScript} from '../packages/ui/src/react/ThemeToggle/ThemeToggle';
export {themeInitScript};
export function App({mode='uncontrolled'}:{mode?:string}) {
 const [count,setCount]=useState(1); const [present,setPresent]=useState(true); const [value,setValue]=useState<'light'|'dark'>('light');
 return <main><h1>ThemeToggle isolated consumer</h1>
 <section aria-label="Theme controls">{present && Array.from({length:count},(_,i)=> <ThemeToggle key={i} locale={i ? 'ar':'en'} {...(mode==='controlled'?{value,onValueChange:(next)=>{setValue(next);(window as any).changes.push(next)}}:{})} />)}</section>
 <button onClick={()=>setCount(n=>n+1)}>Mount another toggle</button><button onClick={()=>setPresent(p=>!p)}>Unmount or remount toggles</button>
 <button onClick={()=>themePreference.set('dark')}>Host sets dark</button><button onClick={()=>themePreference.set('light')}>Host sets light</button>
 {mode==='controlled' && <><ThemeToggle value="light" labels={{toDark:'Use night'}} onValueChange={next=>(window as any).changes.push(next)} /><ThemeToggle value="light" disabled labels={{toDark:'Disabled theme'}} onValueChange={next=>(window as any).changes.push(next)} /></>}
 </main>
}
