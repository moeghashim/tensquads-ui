import React from 'react';
import {hydrateRoot} from 'react-dom/client';
import {App} from './App';
import '../packages/ui/src/fonts.css';
import '../packages/ui/src/tokens/tokens.css';
import '../packages/ui/src/styles/styles.css';
(window as any).changes=[];
hydrateRoot(document.getElementById('root')!, <App mode={new URLSearchParams(location.search).get('mode') || 'uncontrolled'}/> ,{onRecoverableError:error=>{(window as any).hydrationErrors.push(String(error))}});
(window as any).ready=true;
